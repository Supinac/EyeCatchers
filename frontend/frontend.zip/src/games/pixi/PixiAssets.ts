export const PixiAssets = {
  placeholder: [],
};
